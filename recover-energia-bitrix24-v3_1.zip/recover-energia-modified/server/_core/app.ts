import express from "express";
import { createExpressMiddleware } from "@trpc/server/adapters/express";
import { registerOAuthRoutes } from "./oauth";
import { registerEmailAuthRoutes } from "./emailAuth";
import { appRouter } from "../routers";
import { createContext } from "./context";

const BITRIX_WEBHOOK =
  "https://b24-usalxz.bitrix24.com.br/rest/1/c4p3k8s7lhswz1ye/crm.lead.add.json";

export function createApp() {
  const app = express();

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  registerOAuthRoutes(app);
  registerEmailAuthRoutes(app);

  // Rota proxy para o Bitrix24 — resolve o problema de CORS
  app.post("/api/lead", async (req, res) => {
    try {
      const { name, phone, email, energyBillAmount } = req.body;

      if (!name || !phone) {
        res.status(400).json({ error: "Nome e telefone são obrigatórios." });
        return;
      }

      const payload = {
        fields: {
          TITLE: "Lead do Site - Recover Energy",
          NAME: name,
          PHONE: [{ VALUE: phone, VALUE_TYPE: "WORK" }],
          EMAIL: email ? [{ VALUE: email, VALUE_TYPE: "WORK" }] : [],
          COMMENTS: energyBillAmount ? `Conta de energia: ${energyBillAmount}` : "",
        },
      };

      const bitrixRes = await fetch(BITRIX_WEBHOOK, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await bitrixRes.json() as any;

      if (!bitrixRes.ok || data.error) {
        console.error("[Bitrix24] Erro:", data);
        res.status(502).json({ error: data.error_description || data.error || "Erro no Bitrix24" });
        return;
      }

      console.log(`[Bitrix24] Lead criado com sucesso. ID: ${data.result}`);
      res.json({ success: true, leadId: data.result });
    } catch (err: any) {
      console.error("[Bitrix24] Falha ao enviar lead:", err);
      res.status(500).json({ error: "Erro interno ao enviar lead." });
    }
  });

  app.use(
    "/api/trpc",
    createExpressMiddleware({
      router: appRouter,
      createContext,
    })
  );

  return app;
}
