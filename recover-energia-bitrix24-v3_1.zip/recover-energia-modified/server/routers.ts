import { z } from "zod";
import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { notifyOwner } from "./_core/notification";
import { adminProcedure, publicProcedure, router } from "./_core/trpc";
import { systemRouter } from "./_core/systemRouter";
import { createLead, getAllLeads, updateLeadStatus } from "./db";
import { leadStatusEnum } from "../drizzle/schema";

const BITRIX_WEBHOOK =
  "https://b24-usalxz.bitrix24.com.br/rest/1/c4p3k8s7lhswz1ye/crm.lead.add.json";

const leadStatusSchema = z.enum(leadStatusEnum);

const createLeadSchema = z.object({
  name: z.string().trim().min(2, "Informe seu nome"),
  phone: z.string().trim().min(8, "Informe um telefone válido"),
  email: z.string().trim().email("Informe um email válido").optional().or(z.literal("")),
  energyBillAmount: z.string().trim().optional(),
  companyName: z.string().trim().max(160).optional(),
  source: z.string().trim().max(80).optional(),
});

const updateLeadSchema = z.object({
  id: z.number().int().positive(),
  status: leadStatusSchema,
  notes: z.string().trim().max(1200).nullable().optional(),
});

/**
 * Envia o lead para o Bitrix24 via webhook REST
 */
async function sendLeadToBitrix(input: z.infer<typeof createLeadSchema>): Promise<void> {
  const body = {
    fields: {
      TITLE: "Lead do Site - Recover Energy",
      NAME: input.name,
      PHONE: [{ VALUE: input.phone, VALUE_TYPE: "WORK" }],
      EMAIL: input.email ? [{ VALUE: input.email, VALUE_TYPE: "WORK" }] : [],
      COMMENTS: input.energyBillAmount
        ? `Conta de energia: ${input.energyBillAmount}`
        : "",
    },
  };

  const response = await fetch(BITRIX_WEBHOOK, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });

  if (!response.ok) {
    throw new Error(`Bitrix24 respondeu com status ${response.status}`);
  }

  console.log(`[Bitrix24] Lead enviado com sucesso: ${input.name} (${input.phone})`);
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  leads: router({
    create: publicProcedure.input(createLeadSchema).mutation(async ({ input }) => {
      // 1. Enviar para o Bitrix24 (prioridade máxima)
      await sendLeadToBitrix(input).catch((error) => {
        console.warn("[Bitrix24] Erro ao enviar lead:", error);
      });

      // 2. Salvar no banco de dados local (se disponível)
      let createdLead: any = null;
      try {
        createdLead = await createLead({
          name: input.name,
          phone: input.phone,
          email: input.email || "",
          energyBillAmount: input.energyBillAmount || "",
          companyName: input.companyName,
          source: input.source,
        });
      } catch (dbError) {
        console.warn("[Database] Falha ao salvar lead (dados já enviados ao Bitrix24):", dbError);
      }

      // 3. Notificar o owner (best-effort)
      await notifyOwner({
        title: "Novo lead capturado - Recover Energy",
        content: `Nome: ${input.name}\nTelefone: ${input.phone}\nEmail: ${input.email || "-"}\nConta de energia: ${input.energyBillAmount || "-"}`,
      }).catch((error) => {
        console.warn("[Notification] Falha ao notificar owner:", error);
      });

      return {
        success: true,
        leadId: createdLead?.id ?? 0,
      } as const;
    }),

    list: adminProcedure.query(async () => {
      const allLeads = await getAllLeads();
      const totals = {
        total: allLeads.length,
        novo: allLeads.filter((l) => l.status === "novo").length,
        contatado: allLeads.filter((l) => l.status === "contatado").length,
        qualificado: allLeads.filter((l) => l.status === "qualificado").length,
        convertido: allLeads.filter((l) => l.status === "convertido").length,
      };
      return { leads: allLeads, totals };
    }),

    update: adminProcedure.input(updateLeadSchema).mutation(async ({ input }) => {
      const updatedLead = await updateLeadStatus(input);
      return { success: true, lead: updatedLead } as const;
    }),
  }),
});

export type AppRouter = typeof appRouter;
