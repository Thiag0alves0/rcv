import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, leads } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Leads management functions
export async function createLead(input: {
  name: string;
  phone: string;
  email: string;
  energyBillAmount: string;
  companyName?: string;
  source?: string;
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const result = await db.insert(leads).values({
      name: input.name,
      phone: input.phone,
      email: input.email,
      energyBillAmount: input.energyBillAmount,
      companyName: input.companyName,
      source: input.source || "website",
    });

    // Retornar o lead criado
    const leadId = (result as any).insertId;
    const lead = await db.select().from(leads).where(eq(leads.id, leadId)).limit(1);

    return lead[0];
  } catch (error) {
    console.error("[Database] Erro ao criar lead:", error);
    throw error;
  }
}

export async function getAllLeads() {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get leads: database not available");
    return [];
  }

  try {
    const allLeads = await db.select().from(leads).orderBy(desc(leads.createdAt));
    return allLeads;
  } catch (error) {
    console.error("[Database] Erro ao buscar leads:", error);
    return [];
  }
}

export async function updateLeadStatus(input: {
  id: number;
  status: "novo" | "contatado" | "qualificado" | "convertido";
  notes?: string | null;
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    await db.update(leads).set({
      status: input.status,
      notes: input.notes,
    }).where(eq(leads.id, input.id));

    const updatedLead = await db.select().from(leads).where(eq(leads.id, input.id)).limit(1);
    return updatedLead[0];
  } catch (error) {
    console.error("[Database] Erro ao atualizar status do lead:", error);
    throw error;
  }
}

export async function getUserByEmail(email: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.email, email)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createUser(user: {
  email: string;
  password: string;
  name: string;
  role: "admin" | "user";
  loginMethod: string;
}) {
  const db = await getDb();
  if (!db) {
    throw new Error("Database not available");
  }

  try {
    const result = await db.insert(users).values({
      email: user.email,
      password: user.password,
      name: user.name,
      role: user.role,
      loginMethod: user.loginMethod,
    });

    const userId = (result as any).insertId;
    const createdUser = await db.select().from(users).where(eq(users.id, userId)).limit(1);

    return createdUser[0];
  } catch (error) {
    console.error("[Database] Erro ao criar usuário:", error);
    throw error;
  }
}

export async function updateUserLastSignedIn(userId: number) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot update user: database not available");
    return;
  }

  try {
    await db.update(users).set({
      lastSignedIn: new Date(),
    }).where(eq(users.id, userId));
  } catch (error) {
    console.error("[Database] Erro ao atualizar lastSignedIn:", error);
  }
}
