-- Add password column to users table
ALTER TABLE users ADD COLUMN password TEXT AFTER email;

-- Make email unique (if not already)
ALTER TABLE users ADD UNIQUE KEY unique_email (email);
