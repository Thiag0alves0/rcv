import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { MessageCircle, X, Send, Phone } from "lucide-react";

const QUICK_REPLIES = [
  "Como funciona a economia?",
  "Precisa instalar alguma coisa?",
  "Qual é o valor do serviço?",
  "Como faço para contratar?",
];

const ASSISTANT_RESPONSES: Record<string, string> = {
  "como funciona": "A Recover Energy analisa sua conta de energia, identifica oportunidades de economia e implementa soluções personalizadas. O processo é simples: análise → proposta → implementação → economia!",
  "instalar": "Sim, realizamos a instalação de forma segura e rápida. Nossos técnicos especializados garantem que tudo funcione perfeitamente.",
  "valor": "O valor varia conforme sua necessidade. Entre em contato conosco para uma proposta personalizada sem compromisso.",
  "contratar": "Você pode entrar em contato conosco via WhatsApp, email ou preenchendo o formulário de simulação de economia na página.",
};

export default function ChatWidget() {
  const [isOpen, setIsOpen] = useState(false);
  const [messages, setMessages] = useState<Array<{ type: "user" | "bot"; content: string }>>([
    {
      type: "bot",
      content: "Olá! 👋 Bem-vindo à Recover Energy. Como posso ajudá-lo?",
    },
  ]);
  const [inputValue, setInputValue] = useState("");

  const handleSendMessage = (message: string) => {
    if (!message.trim()) return;

    // Add user message
    setMessages(prev => [...prev, { type: "user", content: message }]);
    setInputValue("");

    // Simulate bot response
    setTimeout(() => {
      let response = "Desculpe, não entendi sua pergunta. Você pode tentar uma das opções rápidas ou falar conosco no WhatsApp?";

      for (const [key, value] of Object.entries(ASSISTANT_RESPONSES)) {
        if (message.toLowerCase().includes(key)) {
          response = value;
          break;
        }
      }

      setMessages(prev => [...prev, { type: "bot", content: response }]);
    }, 500);
  };

  const handleQuickReply = (reply: string) => {
    handleSendMessage(reply);
  };

  const handleWhatsApp = () => {
    window.open("https://wa.me/5585981809403?text=Olá, gostaria de saber mais sobre a Recover Energy", "_blank");
  };

  return (
    <>
      {/* Chat Button */}
      {!isOpen && (
        <button
          onClick={() => setIsOpen(true)}
          className="fixed bottom-6 right-6 z-40 w-14 h-14 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full shadow-lg hover:shadow-xl transition-all flex items-center justify-center text-white hover:scale-110"
        >
          <MessageCircle className="w-6 h-6" />
        </button>
      )}

      {/* Chat Window */}
      {isOpen && (
        <Card className="fixed bottom-6 right-6 z-50 w-96 h-[600px] bg-slate-800 border-slate-700 flex flex-col shadow-2xl">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-500 to-blue-600 p-4 flex justify-between items-center rounded-t-lg">
            <div>
              <h3 className="font-bold text-white">Assistente Recover Energy</h3>
              <p className="text-xs text-blue-100">Sempre disponível para ajudar</p>
            </div>
            <button
              onClick={() => setIsOpen(false)}
              className="text-white hover:bg-blue-700 p-1 rounded transition"
            >
              <X className="w-5 h-5" />
            </button>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto p-4 space-y-4">
            {messages.map((msg, idx) => (
              <div
                key={idx}
                className={`flex ${msg.type === "user" ? "justify-end" : "justify-start"}`}
              >
                <div
                  className={`max-w-xs px-4 py-2 rounded-lg ${
                    msg.type === "user"
                      ? "bg-blue-500 text-white rounded-br-none"
                      : "bg-slate-700 text-slate-100 rounded-bl-none"
                  }`}
                >
                  {msg.content}
                </div>
              </div>
            ))}
          </div>

          {/* Quick Replies */}
          {messages.length === 1 && (
            <div className="px-4 py-3 space-y-2 border-t border-slate-700">
              {QUICK_REPLIES.map((reply, idx) => (
                <button
                  key={idx}
                  onClick={() => handleQuickReply(reply)}
                  className="w-full text-left px-3 py-2 bg-slate-700 hover:bg-slate-600 text-slate-100 rounded text-sm transition"
                >
                  {reply}
                </button>
              ))}
            </div>
          )}

          {/* Input Area */}
          <div className="border-t border-slate-700 p-4 space-y-3">
            <div className="flex gap-2">
              <Input
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={(e) => {
                  if (e.key === "Enter") {
                    handleSendMessage(inputValue);
                  }
                }}
                placeholder="Digite sua pergunta..."
                className="bg-slate-700 border-slate-600 text-white placeholder:text-slate-400"
              />
              <Button
                onClick={() => handleSendMessage(inputValue)}
                size="icon"
                className="bg-blue-500 hover:bg-blue-600"
              >
                <Send className="w-4 h-4" />
              </Button>
            </div>
            <Button
              onClick={handleWhatsApp}
              className="w-full bg-green-500 hover:bg-green-600 text-white font-bold flex items-center justify-center gap-2"
            >
              <Phone className="w-4 h-4" />
              Continuar no WhatsApp
            </Button>
          </div>
        </Card>
      )}
    </>
  );
}
